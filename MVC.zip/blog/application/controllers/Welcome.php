<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function about() {
		echo "halaman about";
	}
}	

class Blog extends CI_Controller {
  public function index() {
	  $this->load->view(“blog/index”);

	// $this->load->view("blog/index");
  }

  public function add() {
	echo "halaman tambah blog";
// 	$this->load->view("blog/add");
  }	
}
?>
