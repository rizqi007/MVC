<body>
    <h2>Tambah blog</h2>
    <form action="">
    nama blog: <input type= "text">
    </form>
</body>