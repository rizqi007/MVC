<?php 

	class Bmipasien extends CI_Model {
		// siapkan property
		public $id, $pasien, $tanggal, $bmi;
	}

 ?>